extends Node2D

enum Tool { WALL, DEATH_WALL, START, FINISH, ERASER }

var current_tool = Tool.WALL
var walls: Array = []
var start_point: Dictionary = {}
var finish_point: Dictionary = {}

var drawing := false
var start_pos := Vector2.ZERO

var level_manager = LevelManager.new()

func _process(_delta):
	queue_redraw()

func _draw():
	for wall in walls:
		var col = Color(0.7, 0, 0) if wall.type == "RED" else Color(0.55, 0.15, 0.75)
		draw_rect(Rect2(wall.position, wall.size), col)
	
	if start_point.has("position"):
		draw_rect(Rect2(start_point.position, start_point.size), Color(0, 0.85, 0))
	
	if finish_point.has("position"):
		draw_rect(Rect2(finish_point.position, finish_point.size), Color(1, 1, 0.2))
	
	if drawing:
		var end = get_global_mouse_position()
		var rect = Rect2(start_pos, end - start_pos).abs()
		draw_rect(rect, Color(1, 1, 1, 0.35))

func _input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var mouse = get_global_mouse_position()
		if mouse.x > 1080:
			return
		
		if event.pressed:
			if current_tool == Tool.ERASER:
				erase_at(mouse)
			elif current_tool == Tool.START:
				start_point = {"position": mouse - Vector2(30, 30), "size": Vector2(60, 60)}
			elif current_tool == Tool.FINISH:
				finish_point = {"position": mouse - Vector2(30, 30), "size": Vector2(60, 60)}
			elif current_tool in [Tool.WALL, Tool.DEATH_WALL]:
				drawing = true
				start_pos = mouse
		else:
			if drawing:
				var end = get_global_mouse_position()
				var rect = Rect2(start_pos, end - start_pos).abs()
				if rect.size.x > 10 and rect.size.y > 10:
					var type = "RED" if current_tool == Tool.DEATH_WALL else "PURPLE"
					walls.append({"position": rect.position, "size": rect.size, "type": type})
				drawing = false

func erase_at(pos: Vector2):
	for i in range(walls.size() - 1, -1, -1):
		if Rect2(walls[i].position, walls[i].size).has_point(pos):
			walls.remove_at(i)
			return
	if start_point.has("position") and Rect2(start_point.position, start_point.size).has_point(pos):
		start_point = {}
	if finish_point.has("position") and Rect2(finish_point.position, finish_point.size).has_point(pos):
		finish_point = {}

func _on_wall_pressed(): current_tool = Tool.WALL
func _on_death_pressed(): current_tool = Tool.DEATH_WALL
func _on_start_pressed(): current_tool = Tool.START
func _on_finish_pressed(): current_tool = Tool.FINISH
func _on_eraser_pressed(): current_tool = Tool.ERASER

func _on_save_pressed():
	if not start_point.has("position") or not finish_point.has("position"):
		print("Musisz ustawić START i METĘ!")
		return
	
	var data = {
		"walls": walls,
		"start_point": start_point,
		"finish_point": finish_point
	}
	
	var levels = level_manager.get_level_list()
	var filename = "level_%d.json" % (levels.size() + 1)
	level_manager.save_level(data, filename)

func _on_load_pressed():
	var levels = level_manager.get_level_list()
	
	if levels.is_empty():
		print("Brak zapisanych poziomów!")
		return
	
	var last_level = levels[levels.size() - 1]
	var data = level_manager.load_level(last_level)
	
	if data.is_empty():
		print("Nie udało się wczytać: ", last_level)
		return
	
	walls = data.get("walls", [])
	start_point = data.get("start_point", {})
	finish_point = data.get("finish_point", {})
	
	print("Wczytano: ", last_level)
	queue_redraw()

func _on_back_pressed():
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
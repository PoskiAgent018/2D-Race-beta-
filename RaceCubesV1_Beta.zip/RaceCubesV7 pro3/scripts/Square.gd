extends CharacterBody2D
class_name Square

@export var color_name: String = "GREEN"
@export var is_player: bool = false
@export var player_num: int = 1

var size: float = 30.0
var speed: float = 300.0
var alive: bool = true
var is_invincible: bool = false
var speed_boost_active: bool = false

var ai_direction: Vector2 = Vector2.ZERO

const COLORS = {
	"GREEN": Color(0.2, 1.0, 0.2),
	"RED": Color(1.0, 0.25, 0.25),
	"BLUE": Color(0.25, 0.45, 1.0),
	"YELLOW": Color(1.0, 1.0, 0.25)
}

func _ready():
	# Kolizja
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = Vector2(size, size)
	collision.shape = shape
	add_child(collision)
	
	if not is_player:
		ai_direction = Vector2(randf_range(-1, 1), randf_range(-1, 1)).normalized()
	
	modulate = COLORS.get(color_name, Color.WHITE)
	
	# Wygląd
	var visual = ColorRect.new()
	visual.size = Vector2(size, size)
	visual.position = Vector2(-size/2, -size/2)
	add_child(visual)
	
	if is_player:
		var label = Label.new()
		label.text = str(player_num)
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.size = Vector2(size, size)
		label.position = Vector2(-size/2, -size/2)
		label.add_theme_color_override("font_color", Color.BLACK)
		add_child(label)

func _physics_process(delta):
	if not alive:
		return
	
	if is_player:
		handle_player_movement()
		# Odbijanie od ścian zamiast ślizgania się po nich
		var collision = move_and_collide(velocity * delta)
		if collision:
			velocity = velocity.bounce(collision.get_normal())
	else:
		handle_ai_movement()
		move_and_slide()

func handle_player_movement():
	var dir = Vector2.ZERO
	var current_speed = speed * 1.55 if speed_boost_active else speed
	
	if Input.is_key_pressed(KEY_W):
		dir.y -= 1
	if Input.is_key_pressed(KEY_S):
		dir.y += 1
	if Input.is_key_pressed(KEY_A):
		dir.x -= 1
	if Input.is_key_pressed(KEY_D):
		dir.x += 1
	
	if dir != Vector2.ZERO:
		velocity = dir.normalized() * current_speed
	else:
		velocity = Vector2.ZERO

func handle_ai_movement():
	velocity = ai_direction * speed
	
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		var normal = collision.get_normal()
		ai_direction = ai_direction.bounce(normal).normalized()
		ai_direction = ai_direction.rotated(randf_range(-0.2, 0.2))

func die():
	alive = false
	modulate = Color(0.35, 0.35, 0.35)

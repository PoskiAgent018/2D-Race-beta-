extends Node
class_name LevelManager

const LEVELS_PATH = "user://levels/"
const SETTINGS_PATH = "user://data/settings.json"

func _init():
	DirAccess.make_dir_recursive_absolute(LEVELS_PATH)
	DirAccess.make_dir_recursive_absolute("user://data/")

func save_level(data: Dictionary, filename: String):
	var clean_data = {
		"walls": [],
		"start_point": {},
		"finish_point": {}
	}
	
	for wall in data.get("walls", []):
		clean_data.walls.append({
			"x": wall.position.x,
			"y": wall.position.y,
			"w": wall.size.x,
			"h": wall.size.y,
			"type": wall.type
		})
	
	if data.has("start_point") and data.start_point.has("position"):
		var sp = data.start_point
		clean_data.start_point = {
			"x": sp.position.x,
			"y": sp.position.y,
			"w": sp.size.x,
			"h": sp.size.y
		}
	
	if data.has("finish_point") and data.finish_point.has("position"):
		var fp = data.finish_point
		clean_data.finish_point = {
			"x": fp.position.x,
			"y": fp.position.y,
			"w": fp.size.x,
			"h": fp.size.y
		}
	
	var file = FileAccess.open(LEVELS_PATH + filename, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(clean_data, "\t"))
		file.close()
		print("Zapisano poziom: ", filename)
	else:
		print("Błąd zapisu poziomu!")

func load_level(filename: String) -> Dictionary:
	var path = LEVELS_PATH + filename
	if not FileAccess.file_exists(path):
		return {}
	
	var file = FileAccess.open(path, FileAccess.READ)
	var raw = JSON.parse_string(file.get_as_text())
	file.close()
	
	if not raw:
		return {}
	
	var data = {
		"walls": [],
		"start_point": {},
		"finish_point": {}
	}
	
	for w in raw.get("walls", []):
		data.walls.append({
			"position": Vector2(w.x, w.y),
			"size": Vector2(w.w, w.h),
			"type": w.type
		})
	
	if raw.has("start_point") and raw.start_point.has("x"):
		var sp = raw.start_point
		data.start_point = {
			"position": Vector2(sp.x, sp.y),
			"size": Vector2(sp.w, sp.h)
		}
	
	if raw.has("finish_point") and raw.finish_point.has("x"):
		var fp = raw.finish_point
		data.finish_point = {
			"position": Vector2(fp.x, fp.y),
			"size": Vector2(fp.w, fp.h)
		}
	
	return data

func get_level_list() -> Array:
	var levels = []
	var dir = DirAccess.open(LEVELS_PATH)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if file_name.ends_with(".json"):
				levels.append(file_name)
			file_name = dir.get_next()
	return levels

func save_settings(settings: Dictionary):
	var file = FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(settings, "\t"))
		file.close()

func load_settings() -> Dictionary:
	if not FileAccess.file_exists(SETTINGS_PATH):
		return {
			"speed": 300.0,
			"size": 30.0,
			"ai_count": 4,
			"sound_on": true
		}
	var file = FileAccess.open(SETTINGS_PATH, FileAccess.READ)
	var data = JSON.parse_string(file.get_as_text())
	file.close()
	return data if data else {}

extends Control

func _on_play_pressed():
	get_tree().change_scene_to_file("res://scenes/RaceGame.tscn")

func _on_editor_pressed():
	get_tree().change_scene_to_file("res://scenes/Editor.tscn")

func _on_settings_pressed():
	get_tree().change_scene_to_file("res://scenes/Settings.tscn")

func _on_quit_pressed():
	get_tree().quit()

extends Control

@onready var speed_btn = $VBox/SpeedButton
@onready var size_btn = $VBox/SizeButton
@onready var ai_btn = $VBox/AIButton
@onready var player_btn = $VBox/PlayerButton
@onready var sound_btn = $VBox/SoundButton

var settings = {}
var speed_options = [200.0, 300.0, 450.0]
var size_options = [20.0, 30.0, 40.0]
var ai_options = [2, 4, 6, 8]

var speed_index = 1
var size_index = 1
var ai_index = 1

func _ready():
	var lm = LevelManager.new()
	settings = lm.load_settings()
	
	speed_index = speed_options.find(settings.get("speed", 300.0))
	if speed_index == -1: speed_index = 1
	size_index = size_options.find(settings.get("size", 30.0))
	if size_index == -1: size_index = 1
	ai_index = ai_options.find(settings.get("ai_count", 4))
	if ai_index == -1: ai_index = 1
	
	update_buttons()

func update_buttons():
	speed_btn.text = "Prędkość: " + str(speed_options[speed_index])
	size_btn.text = "Rozmiar: " + str(size_options[size_index])
	ai_btn.text = "Liczba AI: " + str(ai_options[ai_index])
	player_btn.text = "Tryb: " + ("Gracz" if settings.get("player_enabled", true) else "Obserwator")
	sound_btn.text = "Dźwięk: " + ("ON" if settings.sound_on else "OFF")

func _on_speed_pressed():
	speed_index = (speed_index + 1) % speed_options.size()
	settings.speed = speed_options[speed_index]
	update_buttons()

func _on_size_pressed():
	size_index = (size_index + 1) % size_options.size()
	settings.size = size_options[size_index]
	update_buttons()

func _on_ai_pressed():
	ai_index = (ai_index + 1) % ai_options.size()
	settings.ai_count = ai_options[ai_index]
	update_buttons()

func _on_player_pressed():
	settings.player_enabled = not settings.get("player_enabled", true)
	update_buttons()

func _on_sound_pressed():
	settings.sound_on = not settings.sound_on
	update_buttons()

func _on_save_pressed():
	var lm = LevelManager.new()
	lm.save_settings(settings)
	print("Ustawienia zapisane")

func _on_back_pressed():
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

extends Node2D

@onready var pause_menu = $PauseMenu
@onready var win_screen = $WinScreen
@onready var win_label = $WinScreen/Panel/VBox/WinLabel

var player: Square
var level_manager = LevelManager.new()
var settings = {}
var current_level_data: Dictionary = {}
var game_over := false
var is_paused := false

func _ready():
	pause_menu.visible = false
	win_screen.visible = false
	
	settings = level_manager.load_settings()
	
	var levels = level_manager.get_level_list()
	if levels.size() > 0:
		current_level_data = level_manager.load_level(levels.pick_random())
		build_level(current_level_data)
	
	if settings.get("player_enabled", true):
		spawn_player()
	spawn_ai()

func _process(_delta):
	if game_over:
		return
	
	if Input.is_action_just_pressed("ui_cancel") or Input.is_key_pressed(KEY_P):
		if not is_paused:
			toggle_pause()

func toggle_pause():
	is_paused = not is_paused
	get_tree().paused = is_paused
	pause_menu.visible = is_paused

func show_win_screen(color_name: String):
	game_over = true
	get_tree().paused = true
	
	var names = {
		"GREEN": "ZIELONY",
		"RED": "CZERWONY",
		"BLUE": "NIEBIESKI",
		"YELLOW": "ŻÓŁTY"
	}
	win_label.text = "Wygrał kolor:\n" + names.get(color_name, color_name)
	win_screen.visible = true

func _on_resume_pressed():
	toggle_pause()

func _on_pause_settings_pressed():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/Settings.tscn")

func _on_pause_menu_pressed():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _on_win_menu_pressed():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func spawn_player():
	player = Square.new()
	player.is_player = true
	player.color_name = "GREEN"
	player.speed = settings.get("speed", 300.0)
	player.size = settings.get("size", 30.0)
	add_child(player)
	
	# Pozycja startowa wyciągnięta bezpośrednio ze słownika poziomu
	var start_pos = current_level_data.get("start_point", {}).get("position", Vector2.ZERO)
	if start_pos == Vector2.ZERO:
		start_pos = $PlayerSpawn.position if has_node("PlayerSpawn") else Vector2(120, 360)
	player.global_position = start_pos

func spawn_ai():
	var count = settings.get("ai_count", 4)
	for i in count:
		var ai = Square.new()
		ai.is_player = false
		ai.color_name = ["RED", "BLUE", "YELLOW"].pick_random()
		ai.speed = settings.get("speed", 300.0) * 0.9
		ai.size = settings.get("size", 30.0)
		ai.position = Vector2(randi_range(250, 1000), randi_range(80, 640))
		add_child(ai)

func build_level(data: Dictionary):
	if data.has("walls"):
		for w in data.walls:
			create_wall(w)
	
	if data.has("start_point") and data.start_point.has("position"):
		var sp = data.start_point
		if has_node("PlayerSpawn"):
			$PlayerSpawn.position = sp.position + sp.size / 2
		else:
			var m = Marker2D.new()
			m.name = "PlayerSpawn"
			m.position = sp.position + sp.size / 2
			add_child(m)
	
	if data.has("finish_point") and data.finish_point.has("position"):
		var fp = data.finish_point
		var finish = Area2D.new()
		finish.name = "FinishArea"
		
		var shape = RectangleShape2D.new()
		shape.size = fp.size
		
		var col = CollisionShape2D.new()
		col.shape = shape
		col.position = fp.size / 2
		finish.add_child(col)
		
		var vis = ColorRect.new()
		vis.size = fp.size
		vis.color = Color(1, 1, 0.15, 0.45)
		finish.add_child(vis)
		
		finish.position = fp.position
		add_child(finish)
		finish.body_entered.connect(_on_finish_area_body_entered)

func create_wall(data: Dictionary):
	var is_death = data.type == "RED"
	
	var visual = ColorRect.new()
	visual.position = data.position
	visual.size = data.size
	visual.color = Color(0.75, 0.05, 0.05) if is_death else Color(0.55, 0.15, 0.75)
	add_child(visual)
	
	if is_death:
		# Tylko Area2D (bez StaticBody2D) - inaczej kostka nigdy nie
		# "wejdzie" na tyle, by wyzwolić body_entered, bo solidna ściana
		# blokowałaby ruch dokładnie w tym samym miejscu.
		var area = Area2D.new()
		area.position = data.position
		
		var area_shape = RectangleShape2D.new()
		area_shape.size = data.size
		
		var acol = CollisionShape2D.new()
		acol.shape = area_shape
		acol.position = data.size / 2
		area.add_child(acol)
		
		area.body_entered.connect(_on_death_entered)
		add_child(area)
	else:
		var body = StaticBody2D.new()
		body.position = data.position
		
		var shape = RectangleShape2D.new()
		shape.size = data.size
		
		var col = CollisionShape2D.new()
		col.shape = shape
		col.position = data.size / 2
		body.add_child(col)
		add_child(body)

func _on_death_entered(body):
	if game_over or not (body is Square) or not body.alive:
		return
	
	body.die()
	if body.is_player:
		show_win_screen("RED")
	else:
		body.queue_free()

func _on_finish_area_body_entered(body):
	if not game_over and body is Square and body.alive:
		show_win_screen(body.color_name)
